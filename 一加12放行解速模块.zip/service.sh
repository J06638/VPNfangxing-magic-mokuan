#!/system/bin/sh

LOG=/data/local/tmp/netfix_allinone.log
echo "[$(date)] NetFix All-in-One v2.0 started" > $LOG

# 等待系统完全启动
until [ "$(getprop sys.boot_completed)" = "1" ]; do sleep 2; done
sleep 15

# 1. 开启 IPv4 转发
echo 1 > /proc/sys/net/ipv4/ip_forward
echo "[$(date)] ip_forward set to 1" >> $LOG

# 2. 循环守护，每15秒检查并补全所有规则 + 修复MTU
while true; do
    # ========== A. VPN 联网控制放行 (fw_INPUT/fw_OUTPUT) ==========
    if ls /sys/class/net | grep -q tun; then
        iptables -C fw_INPUT -i tun+ -j ACCEPT 2>/dev/null
        if [ $? -ne 0 ]; then
            iptables -I fw_INPUT 1 -i tun+ -j ACCEPT
            echo "[$(date)] [VPN] Rule added in fw_INPUT" >> $LOG
        fi
        iptables -C fw_OUTPUT -o tun+ -j ACCEPT 2>/dev/null
        if [ $? -ne 0 ]; then
            iptables -I fw_OUTPUT 1 -o tun+ -j ACCEPT
            echo "[$(date)] [VPN] Rule added in fw_OUTPUT" >> $LOG
        fi
    fi

    # ========== B. Clash TUN 转发规则 ==========
    # NAT 表：对 tun0 出口做 MASQUERADE
    iptables -t nat -C POSTROUTING -o tun0 -j MASQUERADE 2>/dev/null
    if [ $? -ne 0 ]; then
        iptables -t nat -A POSTROUTING -o tun0 -j MASQUERADE
        echo "[$(date)] [TUN] Added MASQUERADE for tun0" >> $LOG
    fi

    # FORWARD 链：放行 tun0 进出
    iptables -C FORWARD -i tun0 -j ACCEPT 2>/dev/null
    if [ $? -ne 0 ]; then
        iptables -I FORWARD 1 -i tun0 -j ACCEPT
        echo "[$(date)] [TUN] Added FORWARD -i tun0 ACCEPT" >> $LOG
    fi
    iptables -C FORWARD -o tun0 -j ACCEPT 2>/dev/null
    if [ $? -ne 0 ]; then
        iptables -I FORWARD 1 -o tun0 -j ACCEPT
        echo "[$(date)] [TUN] Added FORWARD -o tun0 ACCEPT" >> $LOG
    fi

    # ColorOS 子链放行
    for chain in fw_FORWARD oem_fwd bw_FORWARD; do
        iptables -C $chain -i tun0 -o wlan0 -j ACCEPT 2>/dev/null
        if [ $? -ne 0 ]; then
            iptables -I $chain 1 -i tun0 -o wlan0 -j ACCEPT
            echo "[$(date)] [TUN] Added $chain tun0→wlan0" >> $LOG
        fi
        iptables -C $chain -i wlan0 -o tun0 -j ACCEPT 2>/dev/null
        if [ $? -ne 0 ]; then
            iptables -I $chain 1 -i wlan0 -o tun0 -j ACCEPT
            echo "[$(date)] [TUN] Added $chain wlan0→tun0" >> $LOG
        fi
    done

    # 移动数据接口放行
    for iface in rmnet_data0 rmnet_data1 rmnet_data2; do
        iptables -C FORWARD -i tun0 -o $iface -j ACCEPT 2>/dev/null
        if [ $? -ne 0 ]; then
            iptables -I FORWARD 1 -i tun0 -o $iface -j ACCEPT
        fi
        iptables -C FORWARD -i $iface -o tun0 -j ACCEPT 2>/dev/null
        if [ $? -ne 0 ]; then
            iptables -I FORWARD 1 -i $iface -o tun0 -j ACCEPT
        fi
    done

    # ========== C. MTU 自动修复 ==========
    if ls /sys/class/net | grep -q tun; then
        CURRENT_MTU=$(ip link show tun0 2>/dev/null | grep -oP 'mtu \K[0-9]+')
        if [ -n "$CURRENT_MTU" ] && [ "$CURRENT_MTU" != "1420" ]; then
            ip link set dev tun0 mtu 1420 2>/dev/null
            echo "[$(date)] [MTU] Fixed: $CURRENT_MTU → 1420" >> $LOG
        fi
    fi

    sleep 15
done &